﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProgSessionExemple.UI.Web.Models
{
	public class ArchiveViewModel
	{
		public IDictionary<string, short> Archive { get; set; }
	}
}
